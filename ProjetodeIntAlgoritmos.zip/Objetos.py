class Pessoa:
	def __init__(self, nome):
		self.nome = nome
		self.telefone = 0
		self.bairro = ""
		self.__senha = ""
	
	def _telefone(self, telefone):
		self.telefone = telefone
		
	def _bairro(self, bairro):
		self.bairro = bairro
		
	def _senha(self, senha):
		self.__senha = senha
		
	def _atributos(self):
		return {"Nome": self.nome, "Telefone": self.telefone, "Bairro": self.bairro}
	
	def __atributos(self):
		return {"Nome": self.nome, "Telefone": self.telefone, "Bairro": self.bairro, "Senha": self.__senha}
		
class Paciente(Pessoa):
	pass
		
class Psicologo(Pessoa):
	pass
